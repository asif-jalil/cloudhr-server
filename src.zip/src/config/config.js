module.exports = {
	app: {
		name: process.env.APP_NAME
	}
};
